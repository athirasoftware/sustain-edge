<?php
    use Illuminate\Support\Facades\Crypt;
?>
<div class="modal fade" id="userChangeRole{{crypt::encrypt($user->id)}}" tabindex="-1" role="dialog" aria-labelledby="userChangeRole">
    <div class="modal-dialog">
    <div class="modal-content">
    </div>
    </div>
</div>
