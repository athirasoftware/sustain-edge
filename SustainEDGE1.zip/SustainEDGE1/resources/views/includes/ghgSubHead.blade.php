<div class="topBox">
    <div class="accordHead">
        <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button qusetnBtn" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord1" aria-expanded="true" aria-controls="dashBoarAccord1">
                Qustionnaire
            </button>
        </h2>
        <h2 class="accordion-header" id="headingTwo">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord2" aria-expanded="false" aria-controls="dashBoarAccord2">
                Report
            </button>
        </h2>

        <h2 class="accordion-header" id="headingThree">
            <button class="accordion-button collapsed userBtn" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord3" aria-expanded="false" aria-controls="dashBoarAccord3">
                user
            </button>
        </h2>
        <h2 class="accordion-header" id="headingThree">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord4" aria-expanded="false" aria-controls="dashBoarAccord4">
                settings
            </button>
        </h2>
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" id="gobackBtn">
                GoBack
            </button>
        </h2>
    </div>

</div>