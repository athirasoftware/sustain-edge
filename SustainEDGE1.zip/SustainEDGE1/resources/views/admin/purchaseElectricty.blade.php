@include('includes.header')
<?php

use App\Models\Company;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Auth;

$userCompany =  Company::find(Auth::user()->company_id);
$loginUserId =  Crypt::encrypt(Auth::user()->id);
?>
<div id="pageWrapper" class="cmnPage sidebarPage">

    <section id="scope">
        <div class="container">
            <div class="titleBx">
                <div class="icon">
                    <img src="assets/images/logo.png" alt="">
                </div>
                <h2>GHG Emissions Calculator</h2>
            </div>
            <div class="cmnBx">
                <div class="flx">
                    <div class="lefBx">
                        <div class="name">Hello @if(isset(Auth::user()->full_name) && Auth::user()->full_name != '' ) {{ Auth::user()->full_name }} @else 'Name N/A' @endif
                            @if(Auth::User()->hasRole('Administrator'))
                            (Admin),
                            @elseif(Auth::User()->hasRole('Team Lead'))
                            (Team Lead),
                            @elseif(Auth::User()->hasRole('Employee'))
                            (Employee),
                            @else
                            ,
                            @endif
                        </div>
                        <div class="cmpny">@if(isset($userCompany->name_of_org) && $userCompany->name_of_org != '' ) {{ $userCompany->name_of_org }} @else 'Company N/A'@endif </div>
                        <a href="{{ route('logout') }}" class="links logoutBtn link-text">Logout</a>
                        {{ Form::hidden('encryptedUserId', (isset(Auth::user()->id) && Auth::user()->id != '')?Crypt::encrypt(Auth::user()->id):'', [ 'id' => 'encryptedUserId']) }}
                        <div id="questionariesDiv">
                            <div class="sideBox">
                                @include('includes.sideBar')
                            </div>
                        </div>
                    </div>
                    <div class="rtsec">
                        <div class="topBox">
                            @include('includes.ghgSubHead')
                            <div id="ghgDiv">
                                <div class="accordion" id="dashBoarAccord">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingOne">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord1" aria-expanded="true" aria-controls="dashBoarAccord1">
                                                Qustionnaire
                                            </button>
                                        </h2>
                                        <div id="dashBoarAccord1" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#dashBoarAccord">
                                            <div class="accordion-body ">

                                                <div class="cmnBx">
                                                    <div class="mainTitle">1. Purchase of Electricity</div>
                                                    <form action="javascript:void(0)">
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <label for="">Particulars *</label>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="">Shale oil</option>
                                                                    <option value="">Biodiesel</option>
                                                                </select>
                                                                <div class="label">select the fuel to add them below</div>
                                                            </div>
                                                        </div>
                                                    </form>

                                                    <div class="cmnBx mt-4">
                                                        <div class="row cntr">
                                                            <div class="col-lg-6">
                                                                <div class="txtT">Selected Particulars: <span> Shale Oil</span>
                                                                </div>

                                                            </div>

                                                            <div class="col-lg-6">
                                                                <label for="">Region</label>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="">Shale oil</option>
                                                                    <option value="">Biodiesel</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <label for="">Unit of measurement*</label>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="">Shale oil</option>
                                                                    <option value="">Biodiesel</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <label for="">Quantity (Actual)*</label>
                                                                <input type="text" class="form-control">
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="rtsertBxc">
                                                                    <div class="item">
                                                                        <a href="javascript:void(0)" class="cmnbtn hoveranim"><span>Remove</span></a>
                                                                    </div>
                                                                    <div class="item">
                                                                        <a href="javascript:void(0)" class="cmnbtn hoveranim"><span>Save</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script>

    </script>
</div>

@include('includes.footer')