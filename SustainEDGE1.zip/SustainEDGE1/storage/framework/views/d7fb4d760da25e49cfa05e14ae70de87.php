
    
                            <div class="mainTitle">2.Mobile Combustion</div>
                            <form action="javascript:void(0)">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="">Fuel *</label>
                                        <select name="" id="" class="form-control">
                                            <option value="">Shale oil</option>
                                            <option value="">Biodiesel</option>
                                        </select>
                                        <div class="label">select the fuel to add them below</div>
                                    </div>
                                </div>
                            </form>
                            <div class="item-list">
                                <div class="item">
                                    <div class="itemBx">
                                        <div class="left">
                                            <div class="txtT">Selected Fuel: <span>Anthracite</span>
                                            </div>
                                        </div>
                                        <div class="rtsertBxc">
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Edit</span></a>
                                            </div>
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Remove</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="itemBx">
                                        <div class="left">
                                            <div class="txtT">Selected Fuel: <span>Anthracite</span>
                                            </div>
                                        </div>
                                        <div class="rtsertBxc">
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Edit</span></a>
                                            </div>
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Remove</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="itemBx">
                                        <div class="left">
                                            <div class="txtT">Selected Fuel: <span>Anthracite</span>
                                            </div>
                                        </div>
                                        <div class="rtsertBxc">
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Edit</span></a>
                                            </div>
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Remove</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="itemBx">
                                        <div class="left">
                                            <div class="txtT">Selected Fuel: <span>Anthracite</span>
                                            </div>
                                        </div>
                                        <div class="rtsertBxc">
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Edit</span></a>
                                            </div>
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Remove</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="itemBx">
                                        <div class="left">
                                            <div class="txtT">Selected Fuel: <span>Anthracite</span>
                                            </div>
                                        </div>
                                        <div class="rtsertBxc">
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Edit</span></a>
                                            </div>
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Remove</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="cmnBx mt-4">
                                <div class="row cntr">
                                    <div class="col-lg-4">
                                        <div class="txtT">Selected Fuel: <span> Shale Oil</span>
                                        </div>

                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">Fuel type</label>
                                        <input type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">Region</label>
                                        <select name="" id="" class="form-control">
                                            <option value="">Shale oil</option>
                                            <option value="">Biodiesel</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">Unit of measurement*</label>
                                        <select name="" id="" class="form-control">
                                            <option value="">Shale oil</option>
                                            <option value="">Biodiesel</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-8">
                                        <label for="">Quantity (Actual)*</label>
                                        <input type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="rtsertBxc">
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Remove</span></a>
                                            </div>
                                            <div class="item">
                                                <a href="javascript:void(0)"
                                                    class="cmnbtn hoveranim"><span>Save</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div> 
                        <?php /**PATH C:\xampp\htdocs\SustainEDGE\resources\views/ghg/mobileCombustion.blade.php ENDPATH**/ ?>