<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php

use App\Models\Company;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Auth;

$userCompany =  Company::find(Auth::user()->company_id);
$loginUserId =  Crypt::encrypt(Auth::user()->id);
?>
<div id="pageWrapper" class="cmnPage sidebarPage">

    <section id="scope">
        <div class="container">
            <div class="titleBx">
                <div class="icon">
                    <img src="assets/images/logo.png" alt="">
                </div>
                <h2>GHG Emissions Calculator</h2>
            </div>
            <div class="cmnBx">
                <div class="flx">
                    <div class="lefBx">
                        <div class="name">Hello <?php if(isset(Auth::user()->full_name) && Auth::user()->full_name != '' ): ?> <?php echo e(Auth::user()->full_name); ?> <?php else: ?> 'Name N/A' <?php endif; ?>
                            <?php if(Auth::User()->hasRole('Administrator')): ?>
                            (Admin),
                            <?php elseif(Auth::User()->hasRole('Team Lead')): ?>
                            (Team Lead),
                            <?php elseif(Auth::User()->hasRole('Employee')): ?>
                            (Employee),
                            <?php else: ?>
                            ,
                            <?php endif; ?>
                        </div>
                        <div class="cmpny"><?php if(isset($userCompany->name_of_org) && $userCompany->name_of_org != '' ): ?> <?php echo e($userCompany->name_of_org); ?> <?php else: ?> 'Company N/A'<?php endif; ?> </div>
                        <a href="<?php echo e(route('logout')); ?>" class="links logoutBtn link-text">Logout</a>
                        <?php echo e(Form::hidden('encryptedUserId', (isset(Auth::user()->id) && Auth::user()->id != '')?Crypt::encrypt(Auth::user()->id):'', [ 'id' => 'encryptedUserId'])); ?>

                        <div id="questionariesDiv">
                            <div class="sideBox">
                                <?php echo $__env->make('includes.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="rtsec">
                        <div class="topBox">
                            <?php echo $__env->make('includes.ghgSubHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div id="ghgDiv">
                                <div class="accordion" id="dashBoarAccord">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingOne">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord1" aria-expanded="true" aria-controls="dashBoarAccord1">
                                                Qustionnaire
                                            </button>
                                        </h2>
                                        <div id="dashBoarAccord1" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#dashBoarAccord">
                                            <div class="accordion-body ">

                                                <div class="cmnBx">
                                                    <div class="mainTitle">1. Purchase of Electricity</div>
                                                    <form action="javascript:void(0)">
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <label for="">Particulars *</label>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="">Shale oil</option>
                                                                    <option value="">Biodiesel</option>
                                                                </select>
                                                                <div class="label">select the fuel to add them below</div>
                                                            </div>
                                                        </div>
                                                    </form>

                                                    <div class="cmnBx mt-4">
                                                        <div class="row cntr">
                                                            <div class="col-lg-6">
                                                                <div class="txtT">Selected Particulars: <span> Shale Oil</span>
                                                                </div>

                                                            </div>

                                                            <div class="col-lg-6">
                                                                <label for="">Region</label>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="">Shale oil</option>
                                                                    <option value="">Biodiesel</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <label for="">Unit of measurement*</label>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="">Shale oil</option>
                                                                    <option value="">Biodiesel</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <label for="">Quantity (Actual)*</label>
                                                                <input type="text" class="form-control">
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="rtsertBxc">
                                                                    <div class="item">
                                                                        <a href="javascript:void(0)" class="cmnbtn hoveranim"><span>Remove</span></a>
                                                                    </div>
                                                                    <div class="item">
                                                                        <a href="javascript:void(0)" class="cmnbtn hoveranim"><span>Save</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script>

    </script>
</div>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SustainEDGE1\resources\views/admin/purchaseElectricty.blade.php ENDPATH**/ ?>