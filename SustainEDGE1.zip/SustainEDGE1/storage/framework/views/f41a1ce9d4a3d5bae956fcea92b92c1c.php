<footer>
    <div id="FootSec">
       
    </div>

</footer>
</div>
 


<!-- Modal -->
 

<link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.1.1/dist/select2-bootstrap-5-theme.min.css" />
<!-- Or for RTL support -->
<link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.1.1/dist/select2-bootstrap-5-theme.rtl.min.css" />

 
<script type="text/javascript" src="<?php echo e(URL::To('assets/js/app.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::To('assets/js/commonValidation.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.js"></script>


</body>

</html><?php /**PATH C:\xampp\htdocs\SustainEDGE\resources\views/includes/footer.blade.php ENDPATH**/ ?>