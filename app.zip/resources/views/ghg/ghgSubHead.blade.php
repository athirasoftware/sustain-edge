<div class="topBox">
    <div class="accordHead">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" 
                 id="questionnaireBtn">
                Questionnaire
            </button>
        </h2>
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" 
                 id="reportBtn">
                Report
            </button>
        </h2>

        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" 
                 id="usersBtn">
                Users
            </button>
        </h2>
        <h2 class="accordion-header" >
            <button class="accordion-button collapsed" type="button" 
                 id="settingsBtn">
                Settings
            </button>
        </h2>
        <h2 class="accordion-header" >
            <button class="accordion-button collapsed" type="button" id="gobackBtn">
                GoBack
            </button>
        </h2>
    </div>
</div>

