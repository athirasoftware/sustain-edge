<div class="accordion" id="dashBoarAccord">
<div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#dashBoarAccord4" aria-expanded="false"
            aria-controls="dashBoarAccord4">
            Settings
        </button>
    </h2>
    <div id="dashBoarAccord4" class="accordion-collapse collapse"
        aria-labelledby="headingThree" data-bs-parent="#dashBoarAccord">
        <div class="accordion-body">

        </div>
    </div>
</div>
</div>