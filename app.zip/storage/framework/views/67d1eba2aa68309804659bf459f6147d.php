<?php
    use Illuminate\Support\Facades\Crypt;
?>
<div class="modal fade" id="userChangeRole<?php echo e(crypt::encrypt($user->id)); ?>" tabindex="-1" role="dialog" aria-labelledby="userChangeRole">
    <div class="modal-dialog">
    <div class="modal-content">
    </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SustainEDGE\resources\views/userChangeRole.blade.php ENDPATH**/ ?>