<div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#dashBoarAccord2" aria-expanded="false"
            aria-controls="dashBoarAccord2">
            Report
        </button>
    </h2>
    <div id="dashBoarAccord2" class="accordion-collapse collapse"
        aria-labelledby="headingTwo" data-bs-parent="#dashBoarAccord">
        <div class="accordion-body">

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\SustainEDGE\resources\views/ghg/reports.blade.php ENDPATH**/ ?>