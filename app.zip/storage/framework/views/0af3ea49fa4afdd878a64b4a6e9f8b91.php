<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php

use App\Models\Company;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Auth;

$userCompany =  Company::find(Auth::user()->company_id);
$loginUserId =  Crypt::encrypt(Auth::user()->id);
?>
<div id="pageWrapper" class="cmnPage sidebarPage">

    <section id="scope">
        <div class="container">
            <div class="titleBx">
                <div class="icon">
                    <img src="assets/images/logo.png" alt="">
                </div>
                <h2>GHG Emissions Calculator</h2>
            </div>
            <div class="cmnBx">
                <div class="flx">
                    <div class="lefBx">
                        <div class="name">Hello <?php if(isset(Auth::user()->full_name) && Auth::user()->full_name != '' ): ?> <?php echo e(Auth::user()->full_name); ?> <?php else: ?> 'Name N/A' <?php endif; ?>
                            <?php if(Auth::User()->hasRole('Administrator')): ?>
                            (Admin),
                            <?php elseif(Auth::User()->hasRole('Team Lead')): ?>
                            (Team Lead),
                            <?php elseif(Auth::User()->hasRole('Employee')): ?>
                            (Employee),
                            <?php else: ?>
                            ,
                            <?php endif; ?>
                        </div>
                        <div class="cmpny"><?php if(isset($userCompany->name_of_org) && $userCompany->name_of_org != '' ): ?> <?php echo e($userCompany->name_of_org); ?> <?php else: ?> 'Company N/A'<?php endif; ?> </div>
                        <a href="<?php echo e(route('logout')); ?>" class="links logoutBtn link-text">Logout</a>
                        <?php echo e(Form::hidden('encryptedUserId', (isset(Auth::user()->id) && Auth::user()->id != '')?Crypt::encrypt(Auth::user()->id):'', [ 'id' => 'encryptedUserId'])); ?>

                        <div id="questionariesDiv">
                            <div class="sideBox">
                                <?php echo $__env->make('includes.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="rtsec">
                        <div class="topBox">
                            <?php echo $__env->make('includes.ghgSubHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div id="ghgDiv"></div>
                            <div class="accordion" id="dashBoarAccord">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#dashBoarAccord1" aria-expanded="true" aria-controls="dashBoarAccord1">
                                            Qustionnaire
                                        </button>
                                    </h2>
                                    <div id="dashBoarAccord1" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#dashBoarAccord">
                                        <div class="accordion-body ">

                                            <div class="cmnBx">
                                                <div class="mainTitle">1. Fuel & Energy not in S1 & S2</div>
                                                <form action="javascript:void(0)">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="">Activity *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Region *</label>
                                                            <select name="" id="" class="form-control">
                                                                <option value="">select</option>
                                                            </select>

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">EF Data*</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Scope 1 *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Quantity *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Unit of Measurement *</label>
                                                            <select name="" id="" class="form-control">
                                                                <option value="">select</option>
                                                            </select>

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Scope 2 *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Quantity *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Unit of Measurement *</label>
                                                            <select name="" id="" class="form-control">
                                                                <option value="">select</option>
                                                            </select>

                                                        </div>


                                                        <div class="col-lg-6">
                                                            <label for="">Scope 3 *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Quantity *</label>
                                                            <input type="text" class="form-control">

                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="">Unit of Measurement *</label>
                                                            <select name="" id="" class="form-control">
                                                                <option value="">select</option>
                                                            </select>

                                                        </div>


                                                    </div>
                                                </form>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
</div>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function() {
        $(".purchase_good_service_cancel").on('click', function() {
            $("#purchase_good_service_form")[0].reset();
        })
        $(".purchase_good_service_update").on('click', function() {
            saveOrUpdate('updatePurchaseGoods');
        });
        $(".purchase_good_service_save").on('click', function() {
            saveOrUpdate('savePurchaseGoods');
        });

        function saveOrUpdate(pathName) {
            event.preventDefault();
            $('.error').html('');
            //function addNewUser(formId) {
            var purchase_good_service_item = $.trim($(".purchase_good_service_item").val());
            var supplier_vendor = $.trim($(".supplier_vendor").val());
            var supplier_vendor_gst = $.trim($('.supplier_vendor_gst').val());
            var quantity = $.trim($('.quantity').val());
            var uom = $.trim($(".uom").val());
            var isValid = true;
            if (purchase_good_service_item == '' || typeof purchase_good_service_item === 'undefined') {
                $('.purchase_good_service_itemError').html('Purchased Goods or Service Item Should Not Be Empty');
            }
            if (supplier_vendor == '' || typeof supplier_vendor === 'undefined') {
                $('.supplier_vendorError').html('Supplier/Vendor Should Not Be Empty');
                isValid = false;
            }
            if (supplier_vendor_gst == '' || typeof supplier_vendor_gst === 'undefined') {
                $('.supplier_vendor_gstError').html('Supplier/Vendor GST Should Not Be Empty');
                isValid = false;
            }
            if (quantity == '') {
                $('.quantityError').html('Please Enter Valid Quantity');
                isValid = false;
            }
            if (uom == '') {
                $('.uomError').html('UoM should Not Be Empty');
                isValid = false;
            }
            if (pathName == 'savePurchaseGoods') {
                var urlPath = "<?php echo e(url('/savePurchaseGoods')); ?>";
                var purchase_good_service_item_Id = null;
            } else {
                var urlPath = "<?php echo e(url('/updatePurchaseGoods')); ?>";
                var purchase_good_service_item_Id = $('.purchase_good_service_item_Id').val();
            }
            // console.log(" dept Error isValid => "+isValid);
            if (isValid) {
                // console.log("trying to hit ajax call");
                $.ajax({
                    url: urlPath,
                    method: 'post',
                    dataType: "JSON",
                    data: {
                        "purchase_good_service_item_Id": purchase_good_service_item_Id,
                        "purchase_good_service_item": purchase_good_service_item,
                        "supplier_vendor": supplier_vendor,
                        "supplier_vendor_gst": supplier_vendor_gst,
                        "quantity": quantity,
                        "uom": uom,
                        "_token": "<?php echo e(csrf_token()); ?>",
                    },
                    success: function(data) {
                        // console.log(data);
                        if (data.status == 'success') {
                            //bootbox.alert(data.message);
                            $('#displayMsg').html('');
                            $('#displayMsg').show();
                            $('#displayMsg').html('<span class="success">' + data.message + '</span>');
                            location.reload();
                        } else if (data.status == 'error') {
                            bootbox.alert(data.message);
                        } else if (data.status == 'validation') {
                            // console.log("Todo");
                            $.each(data.messages, function(i, v) {
                                // console.log(i);
                                $("#" + i + "Error").html(v);
                            });
                        }
                    }
                });
            } else {
                console.log("something went wrong with ajax");
            }
        }
    })
</script>
<script type="text/javascript">
    $(document).ready(function() {
        // var activeBtn = 'usersBtn';
        var activeBtn = 'questionnaireBtn';
        setTimeout(() => {
            $('#' + activeBtn).trigger('click');
        }, 500);
        $('#sedge-sub-head').html('');
        $('#questionnaireBtn').click(function(event) {
            $('#sedge-sub-head').html('GHG Emissions Calculator');
            activeBtn = 'questionnaireBtn';
            loadGHGViewByDivId(activeBtn);
        });

        $('#usersBtn').click(function(event) {
            $('#sedge-sub-head').html('Users');
            activeBtn = 'usersBtn';
            loadGHGViewByDivId(activeBtn);
        });

        $('#settingsBtn').click(function(event) {
            $('#sedge-sub-head').html('User Settings');
            activeBtn = 'settingsBtn';
            loadGHGViewByDivId(activeBtn);
        });
        $('#reportBtn').click(function(event) {
            $('#sedge-sub-head').html('User Settings');
            activeBtn = 'reportBtn';
            loadGHGViewByDivId(activeBtn);
        });
        $('#gobackBtn').click(function(event) {
            window.location.href = "<?php echo e(route('home')); ?>";
        });
    });

    function loadGHGViewByDivId(activeBtn) {
        $('.accordion-button').addClass('collapsed');
        $('#' + activeBtn).removeClass('collapsed');
        $('.usersSubList').removeClass('active');
        $("#ghgDiv").html('');
        if (activeBtn == 'usersBtn') {
            $('#allUsersBtn').addClass('active');
            $("#userSideBarDiv").show();
            $("#dashBoarAccord").hide();
            var url = "<?php echo e(URL::TO('ghgUserList')); ?>";
        } else if (activeBtn == 'questionnaireBtn') {
            $("#userSideBarDiv").hide();
            $("#dashBoarAccord").show();
            //var url = "<?php echo e(URL::TO('purchasedgoodsandservices')); ?>";
        } else if (activeBtn == 'reportBtn') {
            $("#userSideBarDiv").hide();
            $("#dashBoarAccord").hide();
            $("#reportsPage").show();
            var url = "<?php echo e(URL::TO('ghgReportData')); ?>";
        } else if (activeBtn == 'settingsBtn') {
            $("#userSideBarDiv").hide();
            $("#dashBoarAccord").hide();
            var loginUserId = $('#loginUserId').val();
            if (loginUserId == '' || typeof loginUserId === 'undefined') {
                bootbox.alert("Invalid User Found!");
            }
            var url = "<?php echo e(URL::TO('/ghgUserEditScreen')); ?>/" + loginUserId;
        }
        if (url != '' && typeof url !== 'undefined') {
            $("#ghgDiv").load(url);
        }
    }


    function loadGHGViewBySubDivId(event) {
        var activeSubBtn = $(event).attr("id");
        $("#ghgDiv").html('');
        $('.usersSubList').removeClass('active');
        // console.log("clicked on "+activeSubBtn);
        $('#' + activeSubBtn).addClass('active');
        if (activeSubBtn == 'allUsersBtn') {
            var url = "<?php echo e(URL::TO('ghgUserList')); ?>";
        } else if (activeSubBtn == 'addNewUsersBtn') {
            var url = "<?php echo e(URL::TO('addGHGNewUser')); ?>";
        }
        if (url != '' && typeof url !== 'undefined') {
            $("#ghgDiv").load(url);
        }
    }

    function editView(randomId, purchase_id) {
        $.ajax({
            url: "<?php echo e(url('/editPurchaseGoods')); ?>",
            method: 'post',
            dataType: "JSON",
            data: {
                "purchase_id": purchase_id,
                "_token": "<?php echo e(csrf_token()); ?>",
            },
            success: function(data) {
                if (data != '') {
                    console.log('testing007')
                    $('.displayMsg').html('');
                    $('.displayMsg').show();
                    $('.displayMsg').html('<span class="success">Please Updated Selected Data!</span>');
                    $(".mainTitle").text('Edit Purchased Goods & Services');
                    $(".purchase_good_service_item").val(data.purchase_item);
                    $(".supplier_vendor").val(data.pur_suplier_info);
                    $(".supplier_vendor_gst").val(data.pur_suplier_gst);
                    $(".quantity").val(data.pur_quantity);
                    $(".uom").val(data.pur_uom);
                    $(".purchase_good_service_item_Id").val(data.id);
                    $(".purchase_good_service_save").addClass('purchase_good_service_save_update').removeClass('purchase_good_service_save');
                    $(".purchase_good_service_save_update span").text('Update');
                } else {
                    console.log('testing555')
                    // bootbox.alert(data.message);
                    $('.displayMsg').html('');
                    $('.displayMsg').show();
                    $('.displayMsg').html('<span class="error">Unable to Edit Selected Record. Contact Admin.</span>');
                }
            }
        });
    }

    function deleteStationaryCombustion(selectedFuelId) {
        // console.log(selectedFuelId);
        $.ajax({
            url: "<?php echo e(url('/deletePurchaseGoods')); ?>",
            method: 'post',
            dataType: "JSON",
            data: {
                "selectedId": selectedFuelId,
                "_token": "<?php echo e(csrf_token()); ?>",
            },
            success: function(data) {
                // console.log(data);
                if (data.status == 'success') {
                    // bootbox.alert(data.message);
                    $('.displayMsg').html('');
                    $('.displayMsg').show();
                    $('.displayMsg').html('<span class="success">' + data.message + '</span>');
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else if (data.status == 'error') {
                    // bootbox.alert(data.message);
                    $('.displayMsg').html('');
                    $('.displayMsg').show();
                    $('.displayMsg').html('<span class="error">' + data.message + '</span>');
                }
            }
        });
    }
</script><?php /**PATH /home4/atqmc2a9/public_html/demo.sustainedge.in/resources/views/scopethree/fuelandenergy.blade.php ENDPATH**/ ?>