<div class="mainTitle" style="text-align:center;font-size: 30px;">Scope1</div>

     <?php if(isset($stationary) && count($stationary) > 0): ?>
     <div class="cmnBx userList" style="marign-bottom:10px;">   
                    <div class="mainTitle">1.Stationary Combution</div>
                        <?php $__currentLoopData = $stationary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->fuel_particular) && $item->fuel_particular != ''): ?>
                                        <?php echo e($item->fuel_particular); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->total_emission) && $item->total_emission != ''): ?>
                                        <?php echo e($item->total_emission); ?> <?php echo e($item->standard); ?>

                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br>
                    <?php endif; ?>
                    <?php if(isset($mobilereports) && count($mobilereports) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">2.Mobile Combution</div>
                        <?php $__currentLoopData = $mobilereports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->fuel_particular) && $item->fuel_particular != ''): ?>
                                        <?php echo e($item->fuel_particular); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->total_emission) && $item->total_emission != ''): ?>
                                        <?php echo e($item->total_emission); ?> <?php echo e($item->standard); ?>

                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>
               
                    <?php if(isset($refrigerants) && count($refrigerants) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">3.Refrigerants</div>
                        <?php $__currentLoopData = $refrigerants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->fuel_particular) && $item->fuel_particular != ''): ?>
                                        <?php echo e($item->fuel_particular); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->total_emission) && $item->total_emission != ''): ?>
                                        <?php echo e($item->total_emission); ?> <?php echo e($item->standard); ?>

                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>
            
        </div>
    </div>
</div>
</div>

<div class="mainTitle" style="text-align:center;font-size: 30px;">Scope2</div>

     <?php if(isset($purchaseofElectricity) && count($purchaseofElectricity) > 0): ?>
     <div class="cmnBx userList" style="marign-bottom:10px;">   
                    <div class="mainTitle">1.Purchase of Electricity</div>
                        <?php $__currentLoopData = $purchaseofElectricity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->fuel_particular) && $item->fuel_particular != ''): ?>
                                        <?php echo e($item->fuel_particular); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->total_emission) && $item->total_emission != ''): ?>
                                        <?php echo e($item->total_emission); ?> <?php echo e($item->standard); ?>

                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
     <?php endif; ?>
         </div>
    </div>
</div>
</div>

<div class="mainTitle" style="text-align:center;font-size: 30px;">Scope3</div>

     <?php if(isset($purchaseGoodsAndService) && count($purchaseGoodsAndService) > 0): ?>
     <div class="cmnBx userList" style="marign-bottom:10px;">   
                    <div class="mainTitle">1.Purchased Goods & Services</div>
                        <?php $__currentLoopData = $purchaseGoodsAndService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->purchase_item) && $item->purchase_item != ''): ?>
                                        <?php echo e($item->purchase_item); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->pur_total_emissions) && $item->pur_total_emissions != ''): ?>
                                        <?php echo e($item->pur_total_emissions); ?>

                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br>
                    <?php endif; ?>
                    <?php if(isset($CapitalGoods) && count($CapitalGoods) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">2.Capital Goods</div>
                        <?php $__currentLoopData = $CapitalGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                           <?php if(isset($item->capital_goods_item) && $item->capital_goods_item != ''): ?>
                                        <?php echo e($item->capital_goods_item); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->cap_total_emissions) && $item->cap_total_emissions != ''): ?>
                                        <?php echo e($item->cap_total_emissions); ?> 
                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>
               
                    <?php if(isset($WasteManagement) && count($WasteManagement) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">3.Waste</div>
                        <?php $__currentLoopData = $WasteManagement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->wa_waste_type) && $item->wa_waste_type != ''): ?>
                                        <?php echo e($item->wa_waste_type); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->wa_total_emissions) && $item->wa_total_emissions != ''): ?>
                                        <?php echo e($item->wa_total_emissions); ?> 
                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>

                    <?php if(isset($BusinessTravel) && count($BusinessTravel) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">4.BusinessTravel</div>
                        <?php $__currentLoopData = $BusinessTravel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->bu_particulars) && $item->bu_particulars != ''): ?>
                                        <?php echo e($item->bu_particulars); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->bu_total_emissions) && $item->bu_total_emissions != ''): ?>
                                        <?php echo e($item->bu_total_emissions); ?> 
                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>

                    <?php if(isset($EmployeeCommute) && count($EmployeeCommute) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">7.EmployeeCommute</div>
                        <?php $__currentLoopData = $EmployeeCommute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->ec_particulars) && $item->ec_waste_type != ''): ?>
                                        <?php echo e($item->ec_waste_type); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->ec_total_emissions) && $item->ec_total_emissions != ''): ?>
                                        <?php echo e($item->ec_total_emissions); ?> 
                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>


                    <?php if(isset($DownStream) && count($DownStream) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">8.Downstream T&D</div>
                        <?php $__currentLoopData = $DownStream; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->ds_particulars) && $item->ds_waste_type != ''): ?>
                                        <?php echo e($item->ds_waste_type); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->ds_total_emissions) && $item->ds_total_emissions != ''): ?>
                                        <?php echo e($item->ds_total_emissions); ?> 
                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?>


                    <!-- <?php if(isset($TransportMode) && count($TransportMode) > 0): ?>
                    <div class="cmnBx userList">     
                    <div class="mainTitle">9.TransportMode</div>
                        <?php $__currentLoopData = $TransportMode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div><label style="font-weight:bold;">Total Emission for 
                                    <?php if(isset($item->motm_transport_mode) && $item->motm_transport_mode != ''): ?>
                                        <?php echo e($item->motm_transport_mode); ?>

                                   
                                    <?php endif; ?>
                                    </label>
                                    <br><span><?php if(isset($item->downStream) && $item->downStream != ''): ?>
                                        <?php echo e($item->downStream); ?> 
                                            
                                    <?php else: ?> 
                                        N/A
                                    <?php endif; ?></span>
                              </div>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                    <?php endif; ?> -->
            
        </div>
    </div>
</div>
</div>
<?php /**PATH /home4/atqmc2a9/public_html/demo.sustainedge.in/resources/views/ghg/reports.blade.php ENDPATH**/ ?>