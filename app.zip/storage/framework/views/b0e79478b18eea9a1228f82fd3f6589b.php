<div class="cmnBx mt-4">
    <div class="row cntr">
       
        <input type="hidden" class="editRandomId" value="<?php echo e($randomId); ?>" />
        <div class="col-lg-4">
        <input type="hidden" name="mobilefuelUOM_<?php echo e($randomId); ?>" id="mobilefuelUOM" value="<?php echo e($selfuelTypes->quantity_type); ?>" />
            <label for="">Region*</label>
            <select name="region_<?php echo e($randomId); ?>" id="region_<?php echo e($randomId); ?>" class="form-control">
                <option value="" >Select Region</option>
                <?php $regionArray = ["India" => "India", "US" => "US", "Europe" => "Europe"]; ?>
                    <?php if(isset($regionArray) && count($regionArray) > 0): ?> 
                        <?php $__currentLoopData = $regionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($id); ?>" <?php if(isset($existingStationaryParticulars->region) && $id == $existingStationaryParticulars->region): ?> selected <?php endif; ?>><?php echo e($region); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            </select>
            <span class="error" id="regionError_<?php echo e($randomId); ?>"> </span>
        </div>
        <div class="col-lg-4">
            <label for="">Unit of measurement*</label>
             <select name="unitOfMesurement" id="unitOfMesurement_<?php echo e($randomId); ?>" class="form-control">
             <option value="">Select Unit of measurement</option>
                    <?php if(isset($fuelTypes) && count($fuelTypes) > 0): ?> 
                        <?php $__currentLoopData = $fuelTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $fuelType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($fuelType) && $fuelType != ''): ?>
                                <option value="<?php echo e($id); ?>" <?php if(isset($existingStationaryParticulars->input_uom) && $id == $existingStationaryParticulars->input_uom): ?> selected <?php endif; ?>><?php echo e($fuelType); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select> 
           
            <span class="error" id="unitOfMesurementError_<?php echo e($randomId); ?>"> </span>
        </div>
        <input type="hidden" name="combustionId_<?php echo e($randomId); ?>" id="combustionId_<?php echo e($randomId); ?>" value="<?php echo e(Crypt::encrypt($combustionId)); ?>" />
        <input type="hidden" name="particularId_<?php echo e($randomId); ?>" id="particularId_<?php echo e($randomId); ?>" value="<?php echo e(Crypt::encrypt($existingStationaryParticulars->fuel_particular_id)); ?>" />
        <div class="col-lg-4">
            <label for="">Quantity (Actual)*</label>
            <input type="text" name="quantityActual_<?php echo e($randomId); ?>" id="quantityActual_<?php echo e($randomId); ?>" value="<?php echo e($existingStationaryParticulars->actual_quantity); ?>" class="form-control">
            <span class="error" id="quantityActualError_<?php echo e($randomId); ?>"> </span>
        </div>
        <!-- <div class="col-lg-4">
            <label for="">Start Date*</label>
            <div class='input-group date startDate' id="startDatetimepicker_<?php echo e($randomId); ?>">
                <?php $startDate = date("m/d/Y", strtotime($existingStationaryParticulars->start_date)); ?>
                <input type='text' name="startDate_<?php echo e($randomId); ?>" id="startDate_<?php echo e($randomId); ?>"  value="<?php echo e($startDate); ?>"  class="form-control" />
                <span class="input-group-addon">
                    <span class="glyphicon glyphicon-calendar"></span>
                </span>
            </div>
            <span class="error" id="startDateError_<?php echo e($randomId); ?>"> </span>
        </div> -->
        <!-- <div class="col-lg-4">
            <label for="">End Date*</label>
            <div class='input-group date endDate' id="endDatetimepicker_<?php echo e($randomId); ?>">
                <?php $selectedEndDate = date("m/d/Y", strtotime($existingStationaryParticulars->end_date)); ?>
                <input type='text' name="endDate_<?php echo e($randomId); ?>" id="endDate_<?php echo e($randomId); ?>"  value="<?php echo e($selectedEndDate); ?>" class="form-control" />
                <span class="input-group-addon">
                    <span class="glyphicon glyphicon-calendar"></span>
                </span>
            </div>
            <span class="error" id="endDateError_<?php echo e($randomId); ?>"> </span>
        </div> -->
        <div class="col-lg-6">
            <div class="rtsertBxc">
                <div class="item">
                    <a href="javascript:void(0)"
                        class="cmnbtn hoveranim removeEdit"  id="removeForm_<?php echo e($randomId); ?>"><span>Cancel</span> <span class="randomNum" style="display:none"></span></a>
                </div>
                <div class="item">
                    <a href="javascript:void(0)" class="cmnbtn hoveranim mobilestationaryUpdate" id="stationaryUpdate_<?php echo e($randomId); ?>"><span>Update</span><span class="randomNum" style="display:none"></span></a>
                </div>
            </div>
        </div>
        <div class="col-lg-12 updateMsg" id="updateMsg_<?php echo e($randomId); ?>" style="display:none"></div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#startDatetimepicker_<?php echo e($randomId); ?>").datepicker({ dateFormat: 'mm/dd/yy' });
        $("#endDatetimepicker_<?php echo e($randomId); ?>").datepicker({ dateFormat: 'mm/dd/yy' });

        $('.removeEdit').on('click', function(){
            // console.log("clicked on removeEdit");
            var editRandomId = '';
            var editRandomIdVal = $(this).attr('id');
           var editRandomIdArray = editRandomIdVal.split("_");
            if(editRandomIdArray[1] != '' && typeof editRandomIdArray[1] !== 'undefined') {
                editRandomId = editRandomIdArray[1];
                $('#selectedViewEdit_'+editRandomId).html('');
                $('#selectedViewEdit_'+editRandomId).hide();
                $('#selectedView_'+editRandomId).show();
            }
        });

        $(".container").on('click', '.mobileRegion', function() {
            var stationaryParticularVal = $('#mobilefuelUOM').val();
        console.log(stationaryParticularVal);
        
        var fuelTypeId = $(this).attr('id');
            var fuelTypeVal = stationaryParticularVal;
            // console.log(" fuelTypeId => "+fuelTypeId+" fuelTypeVal => "+fuelTypeVal);
            var randomId = '';
            var nameIdArray = fuelTypeId.split("_");
            if(nameIdArray[1] != '' && typeof nameIdArray[1] !== 'undefined') {
                randomId = nameIdArray[1];
            }
            var unitOfMeasurementsObj = <?php echo json_encode($unitOfMeasurements); ?>;
            // console.log(unitOfMeasurementsObj);
            var unitOfMeasurementsSubObj = unitOfMeasurementsObj[fuelTypeVal];
            // console.log(unitOfMeasurementsSubObj);
            
            var $el = $("#unitOfMesurement_"+randomId);
            $("#unitOfMesurement_"+randomId+" option:gt(0)").remove();
            // $el.empty(); // remove old options
            $.each(unitOfMeasurementsSubObj, function(key,value) {
                $el.append($("<option></option>")
                .attr("value", key).text(value));
            });
           


           

        });
         
        $(".container").one('click', '.mobilestationaryUpdate', function(e) {
            e.stopPropagation();
            var editRandomId = '';
            var editRandomIdVal = $(this).attr('id');
            var editRandomIdArray = editRandomIdVal.split("_");
            if(editRandomIdArray[1] != '' && typeof editRandomIdArray[1] !== 'undefined') {
                editRandomId = editRandomIdArray[1];
                updateFormMobileCombustionForm(editRandomId);
            } else {
                alert("Something went wrong!");
            }
        });

    });
</script><?php /**PATH /home4/atqmc2a9/public_html/demo.sustainedge.in/resources/views/ghg/editmobileFuel.blade.php ENDPATH**/ ?>